# D1 — Persian Laptop Repair Manager (Android)
Dark RTL Android app, offline local archive, Jalali dates, photos, searchable records and PDF receipts.

## Build APK
- Open this folder in Android Studio (JDK 17; Android SDK 35).
- Sync Gradle, then Build > Build APK(s).
- Debug APK: `app/build/outputs/apk/debug/app-debug.apk`

## Data
Records and image copies are stored privately on device. Export/backup regularly. Uninstalling app can delete local data.
