package ir.d1.repair

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.*
import android.net.Uri
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.*
import java.io.*
import java.text.*
import java.util.*

class MainActivity:AppCompatActivity(){
 private val prefs by lazy{getSharedPreferences("D1",MODE_PRIVATE)}
 private val data=JSONArray(); private lateinit var root:LinearLayout
 private val bg=Color.rgb(16,17,26);private val panel=Color.rgb(29,31,45);private val purple=Color.rgb(139,92,246);private val white=Color.WHITE;private val gray=Color.rgb(170,175,195)
 private var photoUris=mutableListOf<String>()
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);load();home()}
 private fun load(){try{val a=JSONArray(prefs.getString("items","[]"));for(i in 0 until a.length())data.put(a.getJSONObject(i))}catch(_:Exception){}}
 private fun save(){prefs.edit().putString("items",data.toString()).apply()}
 private fun screen(title:String){root=LinearLayout(this).apply{orientation=1;setPadding(20,18,20,24);setBackgroundColor(bg)}
  val sc=ScrollView(this);sc.addView(root);setContentView(sc);txt("D1  •  $title",23,white,true);txt("سامانه ثبت و پیگیری تعمیرات",12,gray)}
 private fun txt(s:String,size:Int=16,c:Int=white,b:Boolean=false){root.addView(TextView(this).apply{text=s;textSize=size.toFloat();setTextColor(c);gravity=Gravity.RIGHT;setPadding(8,10,8,10);if(b)setTypeface(null,1)})}
 private fun btn(s:String,fn:()->Unit){val b=Button(this).apply{text=s;setTextColor(white);backgroundTintList=android.content.res.ColorStateList.valueOf(purple)};root.addView(b);b.setOnClickListener{fn()}}
 private fun input(h:String):EditText{val e=EditText(this).apply{hint=h;setHintTextColor(gray);setTextColor(white);textSize=15;backgroundTintList=android.content.res.ColorStateList.valueOf(purple);gravity=Gravity.RIGHT};root.addView(e);return e}
 private fun spinner(values:Array<String>):Spinner{val s=Spinner(this);s.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,values);root.addView(s);return s}
 private fun home(){screen("داشبورد");txt("خوش اومدی 👋",22,white,true);txt("تعداد کل پرونده‌ها: ${data.length()}",19);listOf("در انتظار تعمیر","در حال تعمیر","آماده تحویل","تحویل شده").forEach{txt("$it: ${count(it)}",15,gray)}
  btn("＋ ثبت پذیرش جدید"){form()};btn("⌕ آرشیو و جستجو"){archive()};btn("پشتیبان‌گیری JSON"){backup()}}
 private fun count(s:String)=(0 until data.length()).count{data.optJSONObject(it)?.optString("status")==s}
 private fun form(){
  screen("پذیرش جدید");txt("ثبت مشخصات دستگاه",18,white,true)
  val name=input("نام مشتری *");val phone=input("شماره تماس");val model=input("مدل لپ‌تاپ *");val acc=input("متعلقات (شارژر، کیف،...)");val fault=input("شرح خرابی *");val repair=input("شرح تعمیر / اقدامات");val cost=input("هزینه تعمیر (تومان)");val dep=input("بیعانه (تومان)")
  txt("وضعیت تعمیر");val st=spinner(arrayOf("در انتظار تعمیر","در حال تعمیر","آماده تحویل","تحویل شده"));txt("وضعیت پرداخت");val pay=spinner(arrayOf("در انتظار پرداخت","پرداخت جزئی","تسویه شده"))
  txt("تصاویر دستگاه",16,purple,true);btn("＋ افزودن عکس"){pickImages()};txt("تعداد عکس انتخاب‌شده: ${photoUris.size}",13,gray)
  btn("ذخیره پرونده و رسید"){if(name.text.isBlank()||model.text.isBlank()||fault.text.isBlank()){toast("نام، مدل و خرابی الزامی است");return@btn}
   val o=JSONObject().put("id",nextId()).put("created",jalali()).put("name",name.text.toString()).put("phone",phone.text.toString()).put("model",model.text.toString()).put("accessories",acc.text.toString()).put("fault",fault.text.toString()).put("repair",repair.text.toString()).put("cost",cost.text.toString()).put("deposit",dep.text.toString()).put("status",st.selectedItem.toString()).put("payment",pay.selectedItem.toString()).put("photos",JSONArray(photoUris))
   data.put(o);save();toast("پرونده #${o.getInt("id")} ذخیره شد");photoUris.clear();detail(o)}
  btn("بازگشت"){home()}
 }
 private fun nextId():Int{var max=0;for(i in 0 until data.length())max=maxOf(max,data.optJSONObject(i)?.optInt("id")?:0);return max+1}
 private fun pickImages(){val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(i,77)}
 override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==77&&c==RESULT_OK&&d!=null){try{if(d.clipData!=null){for(i in 0 until d.clipData!!.itemCount)photoUris.add(copyImage(d.clipData!!.getItemAt(i).uri))}else d.data?.let{photoUris.add(copyImage(it))};toast("${photoUris.size} تصویر انتخاب شد")}catch(e:Exception){toast("خطا در افزودن عکس")}}}
 private fun copyImage(uri:Uri):String{val f=File(filesDir,"img_${System.currentTimeMillis()}.jpg");contentResolver.openInputStream(uri)!!.use{ins->f.outputStream().use{ins.copyTo(it)}};return f.absolutePath}
 private fun archive(){screen("آرشیو");val q=input("جستجوی نام، شماره، مدل یا رسید");btn("جستجو"){results(q.text.toString())};results("")}
 private fun results(q:String){for(i in data.length()-1 downTo 0){val o=data.optJSONObject(i)?:continue;val s="#${o.optInt("id")} • ${o.optString("name")} • ${o.optString("model")} • ${o.optString("status")}";if(q.isBlank()||o.toString().contains(q,true))btn(s){detail(o)}}}
 private fun detail(o:JSONObject){screen("رسید #${o.optInt("id")}");val pairs=listOf("created" to "تاریخ ورود","name" to "مشتری","phone" to "تلفن","model" to "مدل","accessories" to "متعلقات","fault" to "شرح خرابی","repair" to "شرح تعمیر","cost" to "هزینه","deposit" to "بیعانه","payment" to "پرداخت","status" to "وضعیت")
  pairs.forEach{(k,l)->txt("$l: ${o.optString(k,"—")}",15)}
  txt("تاریخ تحویل: ${o.optString("delivered","ثبت نشده")}",16,purple,true)
  btn("ثبت / تغییر تاریخ تحویل"){pickDeliveryDate(o)}
  val a=o.optJSONArray("photos")?:JSONArray();txt("تصاویر پرونده (${a.length()})",16,purple,true)
  for(i in 0 until a.length()){val path=a.optString(i);val f=File(path);if(f.exists()){val iv=ImageView(this);iv.adjustViewBounds=true;iv.maxHeight=420;iv.scaleType=ImageView.ScaleType.FIT_CENTER;iv.setImageURI(Uri.fromFile(f));root.addView(iv)}}
  btn("تغییر وضعیت تعمیر"){val arr=arrayOf("در انتظار تعمیر","در حال تعمیر","آماده تحویل","تحویل شده");AlertDialog.Builder(this).setTitle("وضعیت").setItems(arr){_,n->o.put("status",arr[n]);save();detail(o)}.show()}
  btn("تغییر وضعیت پرداخت"){val arr=arrayOf("در انتظار پرداخت","پرداخت جزئی","تسویه شده");AlertDialog.Builder(this).setTitle("پرداخت").setItems(arr){_,n->o.put("payment",arr[n]);save();detail(o)}.show()}
  btn("خروجی PDF رسید"){pdf(o)};btn("بازگشت آرشیو"){archive()}}
 private fun pickDeliveryDate(o:JSONObject){
  val c=Calendar.getInstance()
  DatePickerDialog(this,{_,y,m,d->
   val pc=PersianCalendar(Calendar.getInstance().apply{set(y,m,d)})
   o.put("delivered","%04d/%02d/%02d".format(pc.year,pc.month,pc.day));save();detail(o)
  },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()
 }
 private fun pdf(o:JSONObject){try{val doc=android.graphics.pdf.PdfDocument();val p=doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,1).create());val paint=Paint().apply{color=Color.BLACK;textSize=16;typeface=Typeface.create("sans-serif",Typeface.NORMAL)}
  val lines=listOf("D1 - رسید پذیرش تعمیر لپ‌تاپ","Receipt #${o.optInt("id")}","تاریخ ورود: ${o.optString("created")}","تاریخ تحویل: ${o.optString("delivered","ثبت نشده")}","مشتری: ${o.optString("name")}","تلفن: ${o.optString("phone")}","مدل: ${o.optString("model")}","متعلقات: ${o.optString("accessories")}","شرح خرابی: ${o.optString("fault")}","شرح تعمیر: ${o.optString("repair")}","هزینه: ${o.optString("cost")}","بیعانه: ${o.optString("deposit")}","پرداخت: ${o.optString("payment")}","وضعیت: ${o.optString("status")}")
  var y=70;lines.forEach{p.canvas.drawText(it,40f,y.toFloat(),paint);y+=38};doc.finishPage(p);val dir=File(getExternalFilesDir(null),"receipts");dir.mkdirs();val f=File(dir,"D1_receipt_${o.optInt("id")}.pdf");FileOutputStream(f).use{doc.writeTo(it)};doc.close()
  val uri=FileProvider.getUriForFile(this,"ir.d1.repair.provider",f);val intent=Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};startActivity(Intent.createChooser(intent,"ارسال یا ذخیره PDF"))
 }catch(e:Exception){toast("ساخت PDF ناموفق: ${e.message}")}}
 private fun backup(){try{val f=File(getExternalFilesDir(null),"D1_backup.json");f.writeText(data.toString());val u=FileProvider.getUriForFile(this,"ir.d1.repair.provider",f);val i=Intent(Intent.ACTION_SEND).apply{type="application/json";putExtra(Intent.EXTRA_STREAM,u);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};startActivity(Intent.createChooser(i,"ذخیره پشتیبان"))}catch(e:Exception){toast("پشتیبان ناموفق")}}
 private fun jalali():String{val c=Calendar.getInstance();val pc=PersianCalendar(c);return "%04d/%02d/%02d".format(pc.year,pc.month,pc.day)}
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
