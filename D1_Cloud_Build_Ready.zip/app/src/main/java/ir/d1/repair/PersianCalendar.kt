package ir.d1.repair
import java.util.Calendar
class PersianCalendar(c:Calendar){private val a=conv(c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH));val year=a[0];val month=a[1];val day=a[2]
 companion object{private fun conv(gy:Int,gm:Int,gd:Int):IntArray{val gdm=intArrayOf(0,31,59,90,120,151,181,212,243,273,304,334);var y=gy-1600;val m=gm-1;val d=gd-1;var days=365*y+(y+3)/4-(y+99)/100+(y+399)/400+gdm[m]+d;if(m>1&&(gy%4==0&&gy%100!=0||gy%400==0))days++;var jy=979+33*(days/12053);days%=12053;jy+=4*(days/1461);days%=1461;if(days>365){jy+=(days-1)/365;days=(days-1)%365};val jm=if(days<186)1+days/31 else 7+(days-186)/30;val jd=1+(if(days<186)days%31 else(days-186)%30);return intArrayOf(jy,jm,jd)}}}
